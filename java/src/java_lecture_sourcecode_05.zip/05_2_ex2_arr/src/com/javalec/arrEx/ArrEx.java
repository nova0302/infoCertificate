package com.javalec.arrEx;

public class ArrEx {
	public static void main(String[] args) {
		
		int[] iArr = new int[5];
		iArr[0] = 10;
		iArr[1] = 20;
		iArr[2] = 30;
		iArr[3] = 40;
		iArr[4] = 50;
		
		for(int i=0; i<5; i++){
			System.out.println(iArr[i]);
		}
		
	}
}

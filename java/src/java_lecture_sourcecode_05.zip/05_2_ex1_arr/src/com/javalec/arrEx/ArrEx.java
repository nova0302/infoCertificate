package com.javalec.arrEx;

public class ArrEx {
	public static void main(String[] args) {
		
		int iArr[] = {10, 20, 30, 40, 50};
		
		for(int i=0; i<iArr.length; i++){
			System.out.println(iArr[i]);
		}
		
	}
}

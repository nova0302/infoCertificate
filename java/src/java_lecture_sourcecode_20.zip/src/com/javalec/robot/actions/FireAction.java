package com.javalec.robot.actions;

public interface FireAction {
	public void fire();
}

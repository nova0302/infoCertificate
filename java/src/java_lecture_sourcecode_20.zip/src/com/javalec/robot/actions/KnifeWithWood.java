package com.javalec.robot.actions;

public class KnifeWithWood implements KnifeAction {

	@Override
	public void knife() {
		// TODO Auto-generated method stub
		System.out.println("����� ��� �մϴ�.");
	}

}

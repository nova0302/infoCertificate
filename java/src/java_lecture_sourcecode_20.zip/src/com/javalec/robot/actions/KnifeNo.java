package com.javalec.robot.actions;

public class KnifeNo implements KnifeAction {

	@Override
	public void knife() {
		// TODO Auto-generated method stub
		System.out.println("���� �����ϴ�.");
	}

}

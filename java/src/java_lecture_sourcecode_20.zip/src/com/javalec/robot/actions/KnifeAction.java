package com.javalec.robot.actions;

public interface KnifeAction {
	public void knife();
}

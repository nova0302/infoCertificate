package com.javalec.robot.actions;

public interface FlyAction {
	public void fly();
}

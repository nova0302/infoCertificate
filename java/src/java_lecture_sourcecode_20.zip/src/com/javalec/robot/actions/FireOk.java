package com.javalec.robot.actions;

public class FireOk implements FireAction {

	@Override
	public void fire() {
		// TODO Auto-generated method stub
		System.out.println("�̻��� �߻�");
	}

}

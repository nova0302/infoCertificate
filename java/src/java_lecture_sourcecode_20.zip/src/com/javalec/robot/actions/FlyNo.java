package com.javalec.robot.actions;

public class FlyNo implements FlyAction {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("���� �����");
	}

}

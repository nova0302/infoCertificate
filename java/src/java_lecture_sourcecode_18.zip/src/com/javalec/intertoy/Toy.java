package com.javalec.intertoy;

public interface Toy {

}

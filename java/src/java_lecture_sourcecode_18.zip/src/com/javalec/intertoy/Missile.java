package com.javalec.intertoy;

public interface Missile extends Toy {
	void canMissile();
}

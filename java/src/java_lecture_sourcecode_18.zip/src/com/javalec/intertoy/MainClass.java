package com.javalec.intertoy;

public class MainClass {
	public static void main(String[] args) {
		
		Toy pooh = new PoohToyClass();
		Toy mazinger = new MazingerToyClass();
		Toy airPlaToy = new AirPlaneToyClass();
		
	}
}

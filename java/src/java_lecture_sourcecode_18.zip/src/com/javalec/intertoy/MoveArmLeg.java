package com.javalec.intertoy;

public interface MoveArmLeg extends Toy {
	void canMoveArmLeg();
}

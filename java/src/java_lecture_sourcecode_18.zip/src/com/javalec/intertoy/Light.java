package com.javalec.intertoy;

public interface Light extends Toy {
	void canLight();
}

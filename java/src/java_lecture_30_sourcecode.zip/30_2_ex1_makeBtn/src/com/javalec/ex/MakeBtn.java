package com.javalec.ex;

import java.awt.Button;
import java.awt.Frame;

public class MakeBtn extends Frame{
	
	public MakeBtn() {
		Button btn = new Button("Button");
		add(btn);
	}
	
}

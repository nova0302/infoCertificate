package com.javalec.ex;

public class MainClass {

	public static void main(String[] args) {
		
		MakeComp makeComp = new MakeComp();
		makeComp.pack();
		makeComp.setVisible(true);
		
	}
	
}

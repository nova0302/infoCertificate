package com.javalec.networkex;

public class MainClass {

	public static void main(String[] args) {
		
		new InetAdressEx();
		
	}
	
	
}
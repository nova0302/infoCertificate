package com.javalec.childlunch;

public class PriceTable {

	public static final int RICE = 1000;
	public static final int BULGOGI = 2000;
	public static final int BANANA = 700;
	public static final int MILK = 200;
	public static final int ALMOND = 100;
	
	
}

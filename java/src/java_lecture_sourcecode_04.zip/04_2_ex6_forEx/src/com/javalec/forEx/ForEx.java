package com.javalec.forEx;

public class ForEx {
	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			
			int result = i + 10;
			System.out.println("i�� " + i + "�Դϴ�. \n" + "10 + i = " + result);
		}
		
	}
}

package com.javalec.forBreakEx;

public class ForBreakEx {
	
	public static void main(String[] args) {
		
		for (int i = 0; i < 5; i++) {
			System.out.println("i�� " + i + "�Դϴ�.");
			if(i >= 3) break;
		}
		
	}
	
}

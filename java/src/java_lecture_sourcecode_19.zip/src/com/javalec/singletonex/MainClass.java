package com.javalec.singletonex;

public class MainClass {

	public static void main(String[] args) {
		
		FirstClass firstClass = new FirstClass();
		SecondClass secondClass = new SecondClass();
		
	}
	
}

package com.javalec.mune;

public class ParentMenu {
	
	public ParentMenu() {
		// TODO Auto-generated constructor stub
	}
	
	public void makeChungGukJang() {
		// TODO Auto-generated method stub
		System.out.println("û����");
	}
	
	public void makeDoenJangGuk() {
		// TODO Auto-generated method stub
		System.out.println("���屹");
	}
	
	public void makeGalbiJjim() {
		// TODO Auto-generated method stub
		System.out.println("������");
	}
	
	public void MakeSoybean() {
		// TODO Auto-generated method stub
		System.out.println("�����");
	}
}

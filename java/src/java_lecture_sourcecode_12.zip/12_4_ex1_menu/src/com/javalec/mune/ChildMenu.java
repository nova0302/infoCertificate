package com.javalec.mune;

public class ChildMenu extends ParentMenu {
	
	public ChildMenu() {
		// TODO Auto-generated constructor stub
	}
	
	private void makeBeefChungGukJang() {
		// TODO Auto-generated method stub
		System.out.println("����� û����");
	}
	
	public void makeHotDoenJangGuk() {
		// TODO Auto-generated method stub
		System.out.println("��ū ���屹");
	}
	
	public void makeKongNaMool() {
		// TODO Auto-generated method stub
		System.out.println("�ᳪ����");
	}
	
	@Override
	public void makeChungGukJang() {
		// TODO Auto-generated method stub
		System.out.println("���� ���� û����");
	}
	
}

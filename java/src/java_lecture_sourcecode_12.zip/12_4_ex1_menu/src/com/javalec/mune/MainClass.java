package com.javalec.mune;


public class MainClass {
	public static void main(String[] args) {
		
		ChildMenu childMenu = new ChildMenu();
		childMenu.makeChungGukJang();
		childMenu.makeDoenJangGuk();
		childMenu.makeGalbiJjim();
		childMenu.makeHotDoenJangGuk();
		childMenu.makeKongNaMool();
		childMenu.MakeSoybean();
		
	}
}

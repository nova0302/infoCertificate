package com.javalec.inheritance;

public class ChildClass extends ParentClass{
	
	String cStr = "�Ƶ� Ŭ����";
	
	public ChildClass() {
		// TODO Auto-generated constructor stub
	}

	
	
}

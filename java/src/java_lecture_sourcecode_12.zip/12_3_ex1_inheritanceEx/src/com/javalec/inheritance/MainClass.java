package com.javalec.inheritance;

public class MainClass {
	
	public static void main(String[] args) {
		
		ChildClass childClass = new ChildClass();
		System.out.print("�ƹ��� �̸� : ");
		childClass.getPapaName();
		System.out.print("��Ӵ� �̸� : ");
		childClass.getMamiName();
		
		System.out.println(childClass.cStr);
		
	}
	
}

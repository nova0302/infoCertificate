package com.javalec.inheritance;

public class ParentClass {
	
	String pStr = "�θ� Ŭ����";
	
	public ParentClass() {
		// TODO Auto-generated constructor stub
	}
	
	public void getPapaName() {
		System.out.println("ȫ�浿");
	}
	
	public void getMamiName() {
		System.out.println("ȫ����");
	}
	

}

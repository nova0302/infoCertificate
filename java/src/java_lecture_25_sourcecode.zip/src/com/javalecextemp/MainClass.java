package com.javalecextemp;


public class MainClass {
	public static void main(String[] args) {
		
		ThrowsExClass throwsExClass = new ThrowsExClass();
		
	}
}

package com.javalec.abstractex;

public class MainClass {
	
	public static void main(String[] args) {
		
		StoreNum1 storeNum1 = new StoreNum1();
		storeNum1.orderKimChijjige();
		storeNum1.orderBiBimbap();
		
	}
	
}

package com.javalec.abstractex;

public class StoreNum3 extends HeadQuarterStore{

	public StoreNum3() {
		// TODO Auto-generated constructor stub
	}
	
}

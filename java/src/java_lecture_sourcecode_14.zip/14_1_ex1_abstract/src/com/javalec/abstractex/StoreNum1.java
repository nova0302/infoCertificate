package com.javalec.abstractex;

public class StoreNum1 extends HeadQuarterStore{

	public StoreNum1() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void orderKimChijjige() {
		System.out.println("4,500�� �Դϴ�.");
	}
	
	@Override
	public void orderBuDaejjige() {
		System.out.println("5,000�� �Դϴ�.");
	}
	
	@Override
	public void orderSunDaeguk() {
		System.out.println("�Ǹ� ���� �ʽ��ϴ�.");
	}
}

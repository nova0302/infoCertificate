package com.javalec.abstractex;

public class StoreNum2 extends HeadQuarterStore{

	public StoreNum2() {
		// TODO Auto-generated constructor stub
	}
	
}

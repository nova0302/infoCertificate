package com.javalec.abstactex;

public class ChildClass extends AbstractClass {

	@Override
	public void wordAbstract() {
		// TODO Auto-generated method stub
		System.out.println("�߻� �޼ҵ带 ������ �մϴ�.");
	}

}

package com.javalec.abstactex;

public class MainClass {
	
	public static void main(String[] args) {
		
		ChildClass childClass = new ChildClass();
		childClass.wordNomal();
		childClass.wordAbstract();
	}
	
}

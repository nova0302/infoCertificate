package com.javalec.abstactex;

public abstract class AbstractClass {

	public AbstractClass() {
		// TODO Auto-generated constructor stub
	}
	
	public void wordNomal() {
		System.out.println("�Ϲ� �޼ҵ� �Դϴ�.");
	}
	
	public abstract void wordAbstract();
		
}

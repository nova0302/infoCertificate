package com.javalec.abstractex;

public class StoreNum2 extends HeadQuarterStore{

	public StoreNum2() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void orderKimChijjige() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void orderBuDaejjige() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void orderBiBimbap() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void orderSunDaeguk() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void orderGongGibap() {
		// TODO Auto-generated method stub
		
	}
	
}

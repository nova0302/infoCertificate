package com.javalec.abstractex;

public abstract class HeadQuarterStore {
	public HeadQuarterStore() {
		// TODO Auto-generated constructor stub
	}
	
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println();
	}
	
	public abstract void orderKimChijjige();
	
	public abstract void orderBuDaejjige();
	
	public abstract void orderBiBimbap();
	
	public abstract void orderSunDaeguk();
	
	public abstract void orderGongGibap();
}

package com.javalec.abstractex;

public class StoreNum1 extends HeadQuarterStore{

	public StoreNum1() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void orderKimChijjige() {
		// TODO Auto-generated method stub
		System.out.println("4,500�� �Դϴ�.");
	}

	@Override
	public void orderBuDaejjige() {
		// TODO Auto-generated method stub
		System.out.println("5,000�� �Դϴ�.");
		
	}

	@Override
	public void orderBiBimbap() {
		// TODO Auto-generated method stub
		System.out.println("6,000�� �Դϴ�.");
		
	}

	@Override
	public void orderSunDaeguk() {
		// TODO Auto-generated method stub
		System.out.println("5,000�� �Դϴ�.");
		
	}

	@Override
	public void orderGongGibap() {
		// TODO Auto-generated method stub
		System.out.println("1,000�� �Դϴ�.");
		
	}
}

package com.javalex.interex;

public interface InterfaceEx {

	public static int CONSTANT_NUM = 1000;
	
	public void calculate();

	
}

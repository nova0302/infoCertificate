package com.javalex.interex;

public interface InterfaceEx2 {

	public static final String CONSTANT_STRING = "HelloWorld!!";
	
	public String getStr();
	
}

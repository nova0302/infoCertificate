package com.javalex.interex;

public class MainClass {
	
	public static void main(String[] args) {
		
		InterfaceClass interfaceClass = new InterfaceClass();
		interfaceClass.getStr();
		interfaceClass.calculate();
		
		
		InterfaceEx ife = new InterfaceClass();
		InterfaceEx2 ife2 = new InterfaceClass();
		
	}
	
}

package com.javalec.poly;

public interface PoliceMan {
	void canCatchCriminal();
	void canSearch();
}

package com.javalec.poly;

public interface Chef {
	void makePizza();
	void makeSpaghetti();
}

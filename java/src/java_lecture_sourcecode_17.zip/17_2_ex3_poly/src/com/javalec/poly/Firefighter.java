package com.javalec.poly;

public interface Firefighter {
	void outFire();
	void saveMan();
}

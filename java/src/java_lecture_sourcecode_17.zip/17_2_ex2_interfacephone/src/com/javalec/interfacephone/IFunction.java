package com.javalec.interfacephone;

public interface IFunction {
	
	void callSenderReceive();
	void canLte();
	void tvRemoteController();
	
}

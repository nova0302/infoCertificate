package com.javalec.timertask;


public class MainClass {
	
	public static void main(String[] args) throws InterruptedException{
		
		TimerEx ex = new TimerEx();
		
	}
	
}

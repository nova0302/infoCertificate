package com.javalec.store;

public class HeadQuarterStore {
	
	public HeadQuarterStore() {
		
	}
		
	public void orderKimChijjige() {
		System.out.println("5,000원 입니다.");
	}
	
	public void orderBuDaejjige() {
		System.out.println("6,000원 입니다.");
	}
	
	public void orderBiBimbap() {
		System.out.println("6,000원 입니다.");
	}
	
	public void orderSunDaeguk() {
		System.out.println("5,000원 입니다.");
	}
	
	public void orderGongGibap() {
		System.out.println("1,000원 입니다.");
	}
	
}

package com.javalec.store;

public class StoreNum3 extends HeadQuarterStore {
	
	public StoreNum3() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void orderKimChijjige() {
		System.out.println("6,000원 입니다.");
	}
	
	@Override
	public void orderBuDaejjige() {
		System.out.println("7,000원 입니다.");
	}
	
	@Override
	public void orderBiBimbap() {
		System.out.println("7,000원 입니다.");
	}
	
	@Override
	public void orderSunDaeguk() {
		System.out.println("6,000원 입니다.");
	}
	
}

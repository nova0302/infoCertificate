package com.javalec.superex;

public class MainClass {
	public static void main(String[] args) {
		
		ChildClass childClass = new ChildClass();
		childClass.method();
		
	}
}

package com.javalec.superex;

public class ParentClass {
	
	public ParentClass() {
		// TODO Auto-generated constructor stub
		System.out.println("ParentClass");
	}
	
	
	public void method() {
		// TODO Auto-generated method stub
		System.out.println("부모 클래스의 method() 입니다.");
	}
}

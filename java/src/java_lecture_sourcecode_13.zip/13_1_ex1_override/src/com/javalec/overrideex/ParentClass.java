package com.javalec.overrideex;

public class ParentClass {
	public ParentClass() {
		// TODO Auto-generated constructor stub
	}
	
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("ParentClass의 메소드");
	}
	
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("ParentClass의 메소드");
	}
}

package com.javalec.overrideex;

public class ChildClass extends ParentClass{
	
	public ChildClass() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("ChildClass의 메소드");
	}
	
	private void method3() {
		// TODO Auto-generated method stub

	}

}

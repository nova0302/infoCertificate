package com.javalec.overrideex;

public class MainClass {
	
	public static void main(String[] args) {
		
		ChildClass childClass = new ChildClass();
		childClass.method1();
		childClass.method2();
		
	}
	
}

package com.javalex.staticfinal;

public class PiClass {
	
	public static final double pi = 3.14D;
	
}

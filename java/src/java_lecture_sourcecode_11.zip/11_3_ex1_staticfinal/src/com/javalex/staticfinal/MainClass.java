package com.javalex.staticfinal;

public class MainClass {
	public static void main(String[] args) {
		
		System.out.println("������ : " + PiClass.pi);
		
	}
}

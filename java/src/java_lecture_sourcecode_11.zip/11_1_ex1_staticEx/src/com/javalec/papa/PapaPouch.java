package com.javalec.papa;

public class PapaPouch {
	
	public static int MONEY = 200;
	
	public PapaPouch() {
		// TODO Auto-generated constructor stub
	}
	
}

package com.javalec.accesstest.sub;

public class AccessTest {
	
	private int a = 10;
	public int b = 20;
	
}

package com.javalec.accesstest;

import com.javalec.accesstest.sub.AccessTest;

public class MainClass {
	public static void main(String[] args) {
		AccessTest accessTest = new AccessTest();
		
		accessTest.a;
		accessTest.b;
		
	}
}

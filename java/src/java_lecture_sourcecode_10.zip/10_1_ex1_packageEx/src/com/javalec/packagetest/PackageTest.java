package com.javalec.packagetest;

public class PackageTest {

}

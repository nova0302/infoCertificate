package com.javalec.cal;

public class PlusClass2 {

}

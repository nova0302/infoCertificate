package com.javalec.cal;

public class PlusClass {
	
	public int plus(int a, int b) {
		return (a + b);
	}
	
}
